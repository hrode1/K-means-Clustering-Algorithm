#include <iostream>
#include <cmath>
#include <iomanip>
using namespace std;

struct Point
{
	double x;
	double y;
};

double distanceTable[8][3];
Point cluster1[8];
Point cluster2[8];
Point cluster3[8];
int cluster1Size=0;
int cluster2Size=0;
int cluster3Size=0;

struct Point centroids[3];

void printCluster(int clusterNum, Point cluster[], int clusterSize)
{
	cout<<"Cluster "<<clusterNum+1<<" :"<<endl;
	for(int i=0;i<clusterSize;i++)
	{
		cout<<"("<<cluster[i].x<<","<<cluster[i].y<<")"<<endl;
	}
}

void calculateCentroid(int clusterNum, Point cluster[], int clusterSize)
{
	double sumX=0,sumY=0;
	for(int i=0;i<clusterSize;i++)
	{
		sumX+=cluster[i].x;
		sumY+=cluster[i].y;
	}
	centroids[clusterNum].x=sumX/clusterSize;
	centroids[clusterNum].y=sumY/clusterSize;
	cout<<"New Centroid : ("<<centroids[clusterNum].x<<","<<centroids[clusterNum].y<<")"<<endl;
}

double getDistance(Point p1, Point p2)
{
	
	return ((p1.x-p2.x)*(p1.x-p2.x)+(p1.y-p2.y)*(p1.y-p2.y));
}

void createDistanceTable(Point points[],Point centroids[])
{
	cout<<"Sum of Squared Error (SSE) Table : \n";
	cout<<"---------------------------------------------------------\n";
	for(int i=0;i<8;i++)
	{
		for(int j=0;j<3;j++)
		{
			distanceTable[i][j]=getDistance(points[i],centroids[j]);
		}
	}
	
	cout<<"\t("<<centroids[0].x<<","<<centroids[0].y<<")\t("<<centroids[1].x<<","<<centroids[1].y<<")\t("<<centroids[2].x<<","<<centroids[2].y<<")\n";
	cout<<"---------------------------------------------------------\n";
	
	// Display the table
	for(int i=0;i<8;i++)
	{
		cout<<"("<<points[i].x<<","<<points[i].y<<")\t|";
		for(int j=0;j<3;j++)
		{
			std::cout << std::setw(10);
			cout<< distanceTable[i][j] <<"\t|";
		}
		cout<<"\n---------------------------------------------------------\n";
	}
}

int minOfThreeNums(double num1, double num2, double num3)
{
	if(num1<num2 && num1<num3)
		return 0;
	else if (num2<num1 && num2<num3)
		return 1;
	else
		return 2;
}

void makeClusters(Point points[])
{
	cluster1Size=0;
    cluster2Size=0;
    cluster3Size=0;
	
	for(int i=0;i<8;i++)
	{
		int temp = minOfThreeNums(distanceTable[i][0],distanceTable[i][1],distanceTable[i][2]);
		if(temp==0)
			cluster1[cluster1Size++]=points[i];
		if(temp==1)
			cluster2[cluster2Size++]=points[i];
		if(temp==2)
			cluster3[cluster3Size++]=points[i];
	}
	
	printCluster(0,cluster1,cluster1Size);
	printCluster(1,cluster2,cluster2Size);
	printCluster(2,cluster3,cluster3Size);
	calculateCentroid(0,cluster1,cluster1Size);
	calculateCentroid(1,cluster2,cluster2Size);
	calculateCentroid(2,cluster3,cluster3Size);
}

int main()
{
	struct Point points[8];
	
	// Point 1
	points[0].x = 1;
	points[0].y = 1;
	
	// Point 2
	points[1].x = 1;
	points[1].y = 2;
	
	// Point 3
	points[2].x = 2;
	points[2].y = 1;
	
	// Point 4
	points[3].x = 2;
	points[3].y = 3;
	
	// Point 5
	points[4].x = 3;
	points[4].y = 3;
	
	// Point 6
	points[5].x = 4;
	points[5].y = 5;
	
	// Point 7
	points[6].x = 5;
	points[6].y = 4;
	
	// Point 8
	points[7].x = 6;
	points[7].y = 5;
	
	cout<<"X\tY\n";
	for(int i=0;i<8;i++)
	{
		cout<<points[i].x<<"\t"<<points[i].y<<"\n";
	}
	
	// Centroid 1
	centroids[0].x = 2;
	centroids[0].y = 3;
	
	// Centroid 2
	centroids[1].x = 3;
	centroids[1].y = 3;
	
	// Centroid 3
	centroids[2].x = 5;
	centroids[2].y = 4;
	
	int k=3;
	
	for(int i=0;i<k;i++)
	{
		cout<<"Centroid "<<i+1<<" : ("<<centroids[i].x<<","<<centroids[i].y<<")\n";
	}
	
	Point oldCentroids[3];
	int i=1;
	do
	{
		cout<<"*************************************************\n";
		cout<<"Iteration "<<i++<<" :"<<endl;
		cout<<"*************************************************\n";
		oldCentroids[0].x=centroids[0].x;
		oldCentroids[0].y=centroids[0].y;
		oldCentroids[1].x=centroids[1].x;
		oldCentroids[1].y=centroids[1].y;
		oldCentroids[2].x=centroids[2].x;
		oldCentroids[2].y=centroids[2].y;
		createDistanceTable(points,centroids);
		makeClusters(points);
		cout<<endl;
	}while(oldCentroids[0].x != centroids[0].x or oldCentroids[0].y != centroids[0].y or
		   oldCentroids[1].x != centroids[1].x or oldCentroids[1].y != centroids[1].y or
		   oldCentroids[2].x != centroids[2].x or oldCentroids[2].y != centroids[2].y);
		
	return 0;
}